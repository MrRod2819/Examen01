


function calcular(){
    const x = document.getElementById("Temperatura").value
    const resultado = (x-32)*5/9
    alert("La temperatura es de: " + resultado)
    
}


